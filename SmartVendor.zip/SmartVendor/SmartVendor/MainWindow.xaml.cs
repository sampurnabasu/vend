﻿using System;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Drawing;
using System.Threading;
using System.Configuration;
using System.Linq;

using Microsoft.ProjectOxford.Face;
using System.IO;
using Microsoft.ProjectOxford.Face.Contract;

using Microsoft.Kinect;
using System.Windows.Media.Imaging;
using System.Collections.Generic;
using System.Windows.Media;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp;
using FireSharp.Response;

using Parse;

using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Auth;
using Microsoft.WindowsAzure.Storage.Blob;

namespace SmartVendor
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //Project Oxford variables
        public FaceServiceClient faceServiceClient = new FaceServiceClient("5017563ebb2d4070b52e16d3869f2a7b");
        string personGroupId = "maindatabase";

        //Kinect variables
        private KinectSensor kinect = null;
        BackgroundRemovalTool _backgroundRemovalTool = null;
        MultiSourceFrameReader reader = null;
        IList<Body> _bodies;
        private WriteableBitmap colorBitmap = null;
        private BitmapSource bitmap = null;
        private BitmapEncoder encoder = null;

        //extensions
        private string result = "";
        private string name = ".jpg";
        private string finalName = "";
        private Boolean faceDetected = false;

        //stuff
        private string state = "None";

        //file path
        private string filePath = @"C:\Users\Sang Woon\Desktop\SmartVendor\shwin.jpg";

        //directory
        private string fileDirectory = @"C:\Users\Sang Woon\Desktop\SmartVendor\target\ben.jpg";


        //Firebase stuff
        IFirebaseConfig config = null;
        IFirebaseClient client = null;
        private int touch = 0;
        private int count = 0;
        private String candyName = "";

        //Azure stuff
        private CloudStorageAccount account = null;
        private CloudBlobClient blob = null;
        private CloudBlobContainer container = null;

        //Parse Stuff
        ParseObject person;

        //counter
        int frame = 0;

        public MainWindow()
        {
            //detectFace();
            //identifyFace();
            // reset();

            kinect = KinectSensor.GetDefault();

            if (kinect != null)
            {
                kinect.Open();
                _backgroundRemovalTool = new BackgroundRemovalTool(kinect.CoordinateMapper);
                FrameDescription colorFrameDescription = this.kinect.ColorFrameSource.CreateFrameDescription(ColorImageFormat.Bgra);
                this.colorBitmap = new WriteableBitmap(colorFrameDescription.Width, colorFrameDescription.Height, 96.0, 96.0, PixelFormats.Bgr32, null);

                reader = kinect.OpenMultiSourceFrameReader(FrameSourceTypes.Color | FrameSourceTypes.Depth | FrameSourceTypes.BodyIndex | FrameSourceTypes.Body);
                reader.MultiSourceFrameArrived += Reader_MultiSourceFrameArrived;
            }

            //instantiating azure stuff
            account = CloudStorageAccount.Parse(ConfigurationManager.AppSettings["StorageConnectionString"]);
            blob = account.CreateCloudBlobClient();
            container = blob.GetContainerReference("picture");
            container.CreateIfNotExists();

            container.SetPermissions(
                new BlobContainerPermissions
                {
                    PublicAccess =
                BlobContainerPublicAccessType.Blob
            });

            //Instantiating firebase stuff
            config = new FirebaseConfig
            {
                AuthSecret = "BGaSOI8goOeHFMn7XMgLkovONzsuf97zTuVyNUdm",
                BasePath = "https://project-vend.firebaseio.com/"
            };

            client = new FirebaseClient(config);

            setTouch();
            setName();

            getCount();

            //instantiating parse stuff
            ParseClient.Initialize("MPqR3vpCyNjg9uKdjWBnFTHaThsXFpyWvmgAGdaF", "xNtyeYpmW47zR02DGY9ukAZ4E0boAsdDv1ulLdGz");

            InitializeComponent();
            //detectFace();
            //definePersonGroup();


        }

        private void Reader_MultiSourceFrameArrived(object sender, MultiSourceFrameArrivedEventArgs e)
        {

            var reference = e.FrameReference.AcquireFrame();

            using (var colorFrame = reference.ColorFrameReference.AcquireFrame())
            using (var depthFrame = reference.DepthFrameReference.AcquireFrame())
            using (var bodyIndexFrame = reference.BodyIndexFrameReference.AcquireFrame())
            {
                if (colorFrame != null && depthFrame != null && bodyIndexFrame != null)
                {
                    bitmap = _backgroundRemovalTool.GreenScreen(colorFrame, depthFrame, bodyIndexFrame);
                    camera.Source = bitmap;

                    frame++;
                    if (frame == 30)
                    {
                        checkTouch();
                        getCandy();
                        frame = 0;
                    }

                   

                    if (state == "Test")
                    {
                        //bitmap = _backgroundRemovalTool.GreenScreen(colorFrame, depthFrame, bodyIndexFrame);
                        
                        if (touch == 1)
                        {
                            setTouch();

                            if (faceDetected == false)
                            {
                                takePicture();
                                faceDetected = true;
                                identifyFace();
                            }

                            
                            count = count + 1;
                            setCount();
                            //Thread.Sleep(3000);
                        }
                    }

                    else if (state == "Demo")
                    {
                        if (touch == 1)
                        {
                            setTouch();
                            takePicture();
                           
                        }
                    }



                    else
                    {
                        //camera.Source = null;
                    }

                    if (candyName != "")
                    {
                        person["candy"] = candyName;
                        setCandyName();
                        candyName = "";
                        updateParse();
                    }


                }
            }
        }

        async void updateParse()
        {
            await person.SaveAsync();
        }
        

        async void reset()
        {
            await faceServiceClient.DeletePersonGroupAsync(personGroupId);
            await faceServiceClient.CreatePersonGroupAsync(personGroupId, "Main Database");
            detectFace(true);
        }

        async void detectFace(bool reset)
        {

            string path = fileDirectory;
            if(reset)
            {
                path = filePath;
            }
            using (Stream s = File.OpenRead(path))
            {
            
             var requiedFaceAttributes = new FaceAttributeType[] {
                FaceAttributeType.Age,
                FaceAttributeType.Gender,
                FaceAttributeType.Smile,
                FaceAttributeType.FacialHair,
                FaceAttributeType.HeadPose
            };
                var faces = await faceServiceClient.DetectAsync(s,
                    returnFaceLandmarks: true,
                    returnFaceAttributes: requiedFaceAttributes);

                foreach (var face in faces)
                {
                    Console.WriteLine("adding to database");
                    faceDetected = false;
                    addPersonToDatabase(face, reset);
                    if (!reset)
                    {
                        person["age"] = face.FaceAttributes.Age;
                        person["gender"] = face.FaceAttributes.Gender;
                        await person.SaveAsync();
                    }

                }
            }
        }

        async void addPersonToDatabase(Face face, Boolean reset)
        {
            var name = "Person" + count;
            Console.WriteLine(face.FaceAttributes.Age + "," + face.FaceAttributes.Gender);
            // Define Person
            var friend1 = await faceServiceClient.CreatePersonAsync(
                // Id of the person group that the person belonged to
                personGroupId,
                // Name of the person
                name,face.FaceAttributes.Age + "," + face.FaceAttributes.Gender
            );

            // Directory contains image files of Ashwin
            //const string friend1ImageDir = @"C:\Users\SmrtAsian\Desktop";
            string path = fileDirectory;
            if (reset)
            {
                path = filePath;
            }
            using (Stream s = File.OpenRead(path))
                {
                // Detect faces in the image and add to Ashwin
                //try {
                    await faceServiceClient.AddPersonFaceAsync(
                        personGroupId, friend1.PersonId, s);
                //} catch(Microsoft.ProjectOxford.Face.FaceAPIException e)
                /*{
                    Console.WriteLine(e.ErrorMessage);
                }*/
                }

            trainGroup(name, reset);

        }

        async void trainGroup(String name, Boolean reset)
        {
            await faceServiceClient.TrainPersonGroupAsync(personGroupId);

            //training
            TrainingStatus trainingStatus = null;
            while (true)
            {
                trainingStatus = await faceServiceClient.GetPersonGroupTrainingStatusAsync(personGroupId);

                if (trainingStatus.Status != Status.Running)
                {
                    break;
                }

                await Task.Delay(1000);
            }
            


        }



        async void identifyFace()
        {

            using (Stream s = File.OpenRead(fileDirectory))
            {
                var faces = await faceServiceClient.DetectAsync(s);
                var faceIds = faces.Select(face => face.FaceId).ToArray();
               try {
                    var results = await faceServiceClient.IdentifyAsync(personGroupId, faceIds);
                    foreach (var identifyResult in results)
                    {
                        //Console.WriteLine("Result of face: {0}", identifyResult.FaceId);
                        if (identifyResult.Candidates.Length == 0)
                        {
                            Console.WriteLine("no one identified");
                            var name = "Person" + count;
                            person = new ParseObject("Person");
                            person["name"] = name;
                            person["candy"] = "Oreos";
                            await person.SaveAsync();
                            setCurrentUser("Person" + count);
                            setPicture();
                            detectFace(false);


                        }
                        else
                        {
                            // Get top 1 among all candidates returned
                            var candidateId = identifyResult.Candidates[0].PersonId;
                            var person1 = await faceServiceClient.GetPersonAsync(personGroupId, candidateId);

                            var query = ParseObject.GetQuery("Person")
                                .WhereEqualTo("name", person1.Name);
                            IEnumerable<ParseObject> people = await query.FindAsync();
                            person = people.First();
                            Console.WriteLine("Identified as {0}", person1.UserData);
                            var list = person1.UserData.Split(',');
                            person["age"] = Convert.ToDouble(list[0]);
                            person["gender"] = list[1];
                            await person.SaveAsync();
                            setCurrentUser(person1.Name);
                            setPicture();
                            faceDetected = false;
                        }
                    }
                } 
                catch(Microsoft.ProjectOxford.Face.FaceAPIException e)
                {
                    Console.WriteLine(e.ErrorMessage);
                    faceDetected = false;
                   
                }
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void Window_Closed(object sender, EventArgs e)
        {
            if (reader != null)
            {
                reader.Dispose();
                reader = null;
            }

            if (kinect != null)
            {
                kinect.Close();
                kinect = null;
            }
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            stateLabel.Content = "Demo";
            state = "Demo";
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            stateLabel.Content = "Test";
            state = "Test";
        }
        
        private void takePicture()
        {
            string folder; 

            if (bitmap != null)
            {
                RenderTargetBitmap renderTargetBitmap = new RenderTargetBitmap(1920, 1080 , 96, 96, PixelFormats.Pbgra32);
                renderTargetBitmap.Render(ben1);    

                encoder = new JpegBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(renderTargetBitmap));
                
                folder = @"C:\Users\Sang Woon\Desktop\SmartVendor\target";
                result = Path.Combine(folder, "ben.jpg");
            }

            try
            {
                // FileStream is IDisposable
                using (FileStream fs = new FileStream(result, FileMode.Create))
                {
                    encoder.Save(fs);
                }

                Console.WriteLine("file saved!");
            }
            catch (IOException)
            {
                Console.WriteLine("file failed!");
            }

            CloudBlockBlob blockBlob = container.GetBlockBlobReference("ben.jpg");

            using (var fileStream = System.IO.File.OpenRead(result))
            {

                blockBlob.UploadFromStream(fileStream);
                Console.WriteLine("Successful!");
            }


        }

        private async void checkTouch()
        {
            FirebaseResponse response = await client.GetAsync("touch");
            touch = response.ResultAs<int>();
            
        }

        private async void setTouch()
        {
            touch = 0;
            try {
                SetResponse response = await client.SetAsync("touch", 0);
            } catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            
        }

        private async void getCount()
        {
            FirebaseResponse response = await client.GetAsync("count");
            count = response.ResultAs<int>();
        }

        private async void getCandy()
        {
            FirebaseResponse response = await client.GetAsync("name");
            candyName = response.ResultAs<String>();
        }

        private async void setCount()
        {
            SetResponse response = await client.SetAsync("count", count);
            //Thread.Sleep(500);
        }

        private async void setPicture()
        {
            SetResponse response = await client.SetAsync("picture", 1);
            //Thread.Sleep(500);
        }
        private async void setPerson()
        {
            SetResponse response = await client.SetAsync("Person", count);
        }

        private async void setCandyName()
        {
            Thread.Sleep(4000);
            SetResponse response = await client.SetAsync(candyName, 0);
            SetResponse response1 = await client.SetAsync("name", "");
        }

        private async void setCurrentUser(String name)
        {
            SetResponse response = await client.SetAsync("currentUser", name);
        }

        private async void setName()
        {
            SetResponse response = await client.SetAsync("name", "");
        }
    }
}
